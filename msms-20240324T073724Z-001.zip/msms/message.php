<style>
    #uni_modal .modal-footer{
        display:none;
    }
</style>
<div class="container">
    <p>Your appointment has successfully submitted and will confirm you as soon as we sees your appointment request. Thank you!</p>
    <div class="text-right">
        <button class="btn btn-sm btn-flat btn-dark" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
    </div>
</div>